// File: com.example.EXP8.StudentPortal.Servlet.AttendanceServlet.java
package com.example.EXP8.StudentPortal.Servlet;

import com.example.EXP8.StudentPortal.Model.Attendance;
import com.example.EXP8.StudentPortal.Util.DBUtil;
import com.example.EXP8.StudentPortal.dao.AttendanceDAO;
import com.example.EXP8.StudentPortal.dao.AttendanceDAOImpl;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.Serializable;
import java.sql.Connection;
import java.text.SimpleDateFormat;
import java.util.Date;

@WebServlet("/AttendanceServlet")
public class AttendanceServlet extends HttpServlet implements Serializable {
    private static final long serialVersionUID = 1L;

    // Adjust DB connection details as needed
    private static final String DB_URL = "jdbc:mysql://localhost:3306/student_portal";
    private static final String DB_USER = "root";
    private static final String DB_PASS = "Saumya@0202";

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int studentId = Integer.parseInt(request.getParameter("studentId"));
        String dateStr = request.getParameter("date");
        String status = request.getParameter("status");
        String remarks = request.getParameter("remarks");

        try (Connection conn = DBUtil.getConnection()) {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            Date date = sdf.parse(dateStr);

            Attendance attendance = new Attendance();
            attendance.setStudentId(studentId);
            attendance.setDate(date);
            attendance.setStatus(status);
            attendance.setRemarks(remarks);

            AttendanceDAO dao = new AttendanceDAOImpl(conn);
            boolean success = dao.saveAttendance(attendance); // Make sure this method is implemented in DAO

            if (success) {
                response.sendRedirect("success.jsp");
            } else {
                response.sendRedirect("error.jsp");
            }

        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("error.jsp");
        }
    }
}
