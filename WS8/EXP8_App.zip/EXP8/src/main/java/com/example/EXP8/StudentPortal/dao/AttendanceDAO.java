package com.example.EXP8.StudentPortal.dao;

import com.example.EXP8.StudentPortal.Model.Attendance;
import java.util.List;

public interface AttendanceDAO {
    void addAttendance(Attendance attendance);
    List<Attendance> getAttendanceByStudentId(int studentId);
    List<Attendance> getAllAttendance();
    void updateAttendance(Attendance attendance);
    void deleteAttendance(int attendanceId);

    boolean saveAttendance(Attendance attendance);
}
