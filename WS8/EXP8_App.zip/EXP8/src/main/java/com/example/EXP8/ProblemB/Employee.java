package com.example.EXP8.ProblemB;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.Date;

@Data
@AllArgsConstructor
public class Employee {
    private int id;
    private String name;
    private String position;
    private double salary;
    private Date hireDate;
}
