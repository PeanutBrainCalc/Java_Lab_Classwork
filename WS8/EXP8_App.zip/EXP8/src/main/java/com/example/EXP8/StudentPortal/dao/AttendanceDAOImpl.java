package com.example.EXP8.StudentPortal.dao;

import com.example.EXP8.StudentPortal.Model.Attendance;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AttendanceDAOImpl implements AttendanceDAO {

    private final Connection conn;

    public AttendanceDAOImpl(Connection conn) {
        this.conn = conn;
    }

    @Override
    public void addAttendance(Attendance attendance) {
        saveAttendance(attendance); // Reuse existing method
    }

    @Override
    public boolean saveAttendance(Attendance attendance) {
        String sql = "INSERT INTO attendance(student_id, date, status, remarks) VALUES (?, ?, ?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, attendance.getStudentId());
            stmt.setDate(2, new java.sql.Date(attendance.getDate().getTime()));
            stmt.setString(3, attendance.getStatus());
            stmt.setString(4, attendance.getRemarks());
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public List<Attendance> getAttendanceByStudentId(int studentId) {
        List<Attendance> records = new ArrayList<>();
        String sql = "SELECT * FROM attendance WHERE student_id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, studentId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Attendance attendance = new Attendance();
                attendance.setAttendanceId(rs.getInt("attendance_id"));
                attendance.setStudentId(rs.getInt("student_id"));
                attendance.setDate(rs.getDate("date"));
                attendance.setStatus(rs.getString("status"));
                attendance.setRemarks(rs.getString("remarks"));
                records.add(attendance);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return records;
    }

    @Override
    public List<Attendance> getAllAttendance() {
        List<Attendance> records = new ArrayList<>();
        String sql = "SELECT * FROM attendance";
        try (Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Attendance attendance = new Attendance();
                attendance.setAttendanceId(rs.getInt("attendance_id"));
                attendance.setStudentId(rs.getInt("student_id"));
                attendance.setDate(rs.getDate("date"));
                attendance.setStatus(rs.getString("status"));
                attendance.setRemarks(rs.getString("remarks"));
                records.add(attendance);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return records;
    }

    @Override
    public void updateAttendance(Attendance attendance) {
        String sql = "UPDATE attendance SET student_id = ?, date = ?, status = ?, remarks = ? WHERE attendance_id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, attendance.getStudentId());
            stmt.setDate(2, new java.sql.Date(attendance.getDate().getTime()));
            stmt.setString(3, attendance.getStatus());
            stmt.setString(4, attendance.getRemarks());
            stmt.setInt(5, attendance.getAttendanceId());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void deleteAttendance(int attendanceId) {
        String sql = "DELETE FROM attendance WHERE attendance_id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, attendanceId);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}





