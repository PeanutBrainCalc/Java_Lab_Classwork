package com.example.EXP8.StudentPortal.Servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.example.EXP8.StudentPortal.Util.DBUtil;

@WebServlet("/StudentServlet")
public class StudentServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String action = request.getParameter("action");

        if ("submitAttendance".equals(action)) {
            int studentId = Integer.parseInt(request.getParameter("studentId"));
            String date = request.getParameter("date");
            String status = request.getParameter("status");
            String remarks = request.getParameter("remarks");

            try (Connection conn = DBUtil.getConnection()) {
                String sql = "INSERT INTO attendance(student_id, date, status, remarks) VALUES (?, ?, ?, ?)";
                try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                    stmt.setInt(1, studentId);
                    stmt.setString(2, date);
                    stmt.setString(3, status);
                    stmt.setString(4, remarks);
                    stmt.executeUpdate();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }

            response.sendRedirect("success.jsp");  // Create a success page if needed
        }
    }
}
