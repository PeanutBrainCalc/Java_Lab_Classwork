package com.example.EXP8.ProblemB;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


@WebServlet("/EmployeeServlet")
public class EmployeeServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        String empIdParam = request.getParameter("empId");
        Connection conn = null;

        try {
            conn = DBUtil.getConnection();
            List<Employee> employees = new ArrayList<>();

            if (empIdParam != null && !empIdParam.trim().isEmpty()) {
                // Search for specific employee
                int empId = Integer.parseInt(empIdParam);
                PreparedStatement pstmt = conn.prepareStatement("SELECT * FROM employees WHERE id = ?");
                pstmt.setInt(1, empId);
                ResultSet rs = pstmt.executeQuery();

                while (rs.next()) {
                    Employee emp = new Employee(
                            rs.getInt("id"),
                            rs.getString("name"),
                            rs.getString("position"),
                            rs.getDouble("salary"),
                            rs.getDate("hire_date")
                    );
                    employees.add(emp);
                }
                rs.close();
                pstmt.close();
            } else {
                // Fetch all employees
                PreparedStatement pstmt = conn.prepareStatement("SELECT * FROM employees");
                ResultSet rs = pstmt.executeQuery();

                while (rs.next()) {
                    Employee emp = new Employee(
                            rs.getInt("id"),
                            rs.getString("name"),
                            rs.getString("position"),
                            rs.getDouble("salary"),
                            rs.getDate("hire_date")
                    );
                    employees.add(emp);
                }
                rs.close();
                pstmt.close();
            }

            // HTML Response
            out.println("<!DOCTYPE html><html><head><title>Employee Directory</title><style>");
            out.println("body { font-family: Arial, sans-serif; margin: 40px; }");
            out.println(".container { width: 80%; max-width: 800px; margin: 0 auto; }");
            out.println("table { width: 100%; border-collapse: collapse; }");
            out.println("th, td { padding: 10px; text-align: left; border-bottom: 1px solid #ddd; }");
            out.println("th { background-color: #f2f2f2; }");
            out.println(".search-box { padding: 20px; background-color: #f5f5f5; border-radius: 5px; margin-bottom: 20px; }");
            out.println("input[type='text'] { padding: 8px; width: 200px; }");
            out.println("button { padding: 8px 15px; background-color: #4CAF50; color: white; border: none; cursor: pointer; }");
            out.println("a.button { padding: 8px 15px; background-color: #2196F3; color: white; text-decoration: none; border-radius: 3px; margin-left: 10px; display: inline-block; }");
            out.println(".no-results { background-color: #f8d7da; color: #721c24; padding: 15px; border-radius: 5px; }");
            out.println("</style></head><body>");
            out.println("<div class='container'>");
            out.println("<h1>Employee Directory</h1>");

            out.println("<div class='search-box'>");
            out.println("<h3>Search Employee by ID</h3>");
            out.println("<form action='EmployeeServlet' method='get'>");
            out.println("<input type='text' name='empId' placeholder='Enter Employee ID' value='" +
                    (empIdParam != null ? empIdParam : "") + "'>");
            out.println("<button type='submit'>Search</button>");
            out.println("<a href='EmployeeServlet' class='button'>View All Employees</a>");
            out.println("</form></div>");

            if (employees.isEmpty()) {
                out.println("<div class='no-results'><h3>No employees found</h3></div>");
            } else {
                out.println("<table><tr><th>ID</th><th>Name</th><th>Position</th><th>Salary</th><th>Hire Date</th></tr>");
                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                for (Employee emp : employees) {
                    out.println("<tr>");
                    out.println("<td>" + emp.getId() + "</td>");
                    out.println("<td>" + emp.getName() + "</td>");
                    out.println("<td>" + emp.getPosition() + "</td>");
                    out.println("<td>$" + String.format("%.2f", emp.getSalary()) + "</td>");
                    out.println("<td>" + dateFormat.format(emp.getHireDate()) + "</td>");
                    out.println("</tr>");
                }
                out.println("</table>");
            }

            out.println("</div></body></html>");

        } catch (SQLException e) {
            out.println("<h3>Database Error: " + e.getMessage() + "</h3>");
            e.printStackTrace();
        } catch (NumberFormatException e) {
            out.println("<h3>Invalid Employee ID format</h3>");
        } finally {
            DBUtil.closeConnection(conn);
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }
}
