package com.example.EXP8.StudentPortal.Model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Attendance {
    private int attendanceId;
    private int studentId;
    private Date date;
    private String status;
    private String remarks;
}
