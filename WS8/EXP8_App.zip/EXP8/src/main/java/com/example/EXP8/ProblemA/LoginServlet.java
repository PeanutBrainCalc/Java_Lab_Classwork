package com.example.EXP8.ProblemA;

import java.io.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


@WebServlet("/login")
public class LoginServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws IOException {

        String username = request.getParameter("username");
        String password = request.getParameter("password");

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        if ("admin".equals(username) && "password".equals(password)) {
            out.println("<html><body style='font-family:sans-serif; text-align:center; margin-top:50px;'>");
            out.println("<h2>Welcome, " + username + "!</h2>");
            out.println("<p>Login successful. Have a great day!</p>");
            out.println("</body></html>");
        } else {
            out.println("<html><body style='font-family:sans-serif; text-align:center; margin-top:50px;'>");
            out.println("<h2>Login Failed!</h2>");
            out.println("<p>Invalid username or password. Please <a href='login.html'>try again</a>.</p>");
            out.println("</body></html>");
        }
    }
}
